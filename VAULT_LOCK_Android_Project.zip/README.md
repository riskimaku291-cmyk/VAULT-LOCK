# VAULT LOCK — Android

Aplikasi demo kunci PIN di dalam aplikasi dengan tema futuristik hitam-emas.

## PIN awal
`1234`

Segera ganti PIN setelah aplikasi dibuka.

## Membuat APK melalui GitHub dari HP Android
1. Buat repository GitHub baru bernama `VAULT-LOCK`.
2. Upload seluruh isi folder proyek ini ke repository (bukan folder ZIP-nya).
3. Buat file `.github/workflows/android.yml` dengan isi workflow yang disediakan.
4. Buka tab **Actions**, pilih workflow **Build VAULT LOCK APK**, lalu tekan **Run workflow**.
5. Setelah selesai, buka hasil run dan unduh artifact `VAULT-LOCK-debug-apk`.
6. Ekstrak ZIP artifact, lalu instal `app-debug.apk` di HP Android.

Catatan: aplikasi ini mengunci halaman di dalam VAULT LOCK, bukan menggantikan lock screen Android.
