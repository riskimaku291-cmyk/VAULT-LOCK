package com.vaultlock.app

import android.app.Activity
import android.os.Bundle
import android.content.Context
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private val gold = 0xFFFFC857.toInt()
    private val dark = 0xFF090B10.toInt()
    private val panel = 0xFF171B24.toInt()
    private val prefs by lazy { getSharedPreferences("vault_settings", Context.MODE_PRIVATE) }
    private var entered = ""
    private var mode = "unlock"
    private var newPin = ""
    private lateinit var root: LinearLayout
    private lateinit var dots: TextView
    private lateinit var message: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = dark
        window.navigationBarColor = dark
        showLock()
    }

    private fun pin(): String = prefs.getString("pin", "1234") ?: "1234"

    private fun background(color: Int, radius: Float, stroke: Int = 0): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius
            if (stroke != 0) setStroke(2, stroke)
        }

    private fun text(value: String, size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            gravity = Gravity.CENTER
            if (bold) setTypeface(Typeface.DEFAULT, Typeface.BOLD)
        }

    private fun setup(title: String, subtitle: String) {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(24, 28, 24, 24)
            setBackgroundColor(dark)
        }
        setContentView(root)
        root.addView(text("◆  V A U L T   L O C K  ◆", 17f, gold, true),
            LinearLayout.LayoutParams(-1, 48))
        root.addView(text(title, 25f, 0xFFFFFFFF.toInt(), true),
            LinearLayout.LayoutParams(-1, 48))
        root.addView(text(subtitle, 13f, 0xFF9CA3AF.toInt()),
            LinearLayout.LayoutParams(-1, 34))
    }

    private fun addVaultIcon() {
        val frame = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            background = background(panel, 500f, gold)
        }
        frame.addView(text("◉", 86f, gold, true))
        val p = LinearLayout.LayoutParams(190, 190)
        p.setMargins(0, 18, 0, 18)
        root.addView(frame, p)
    }

    private fun showLock() {
        mode = "unlock"
        entered = ""
        setup("SYSTEM TERKUNCI", "MASUKKAN PIN UNTUK MEMBUKA BRANKAS")
        addVaultIcon()
        dots = text("○   ○   ○   ○", 27f, gold, true)
        root.addView(dots, LinearLayout.LayoutParams(-1, 48))
        message = text("STATUS: MENUNGGU OTENTIKASI", 12f, 0xFF9CA3AF.toInt())
        root.addView(message, LinearLayout.LayoutParams(-1, 34))
        addKeypad()
        val settings = makeButton("⚙  GANTI PIN", false)
        settings.setOnClickListener { startChangePin() }
        root.addView(settings, LinearLayout.LayoutParams(-1, 48))
        root.addView(text("SECURE ACCESS  •  VAULT OS 1.0", 10f, 0xFF626B7A.toInt()),
            LinearLayout.LayoutParams(-1, 34))
    }

    private fun addKeypad() {
        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val nums = listOf(listOf("1","2","3"), listOf("4","5","6"), listOf("7","8","9"), listOf("⌫","0","C"))
        nums.forEach { row ->
            val line = LinearLayout(this).apply { gravity = Gravity.CENTER }
            row.forEach { n ->
                val b = makeButton(n, true)
                b.setOnClickListener {
                    when (n) {
                        "⌫" -> if (entered.isNotEmpty()) entered = entered.dropLast(1)
                        "C" -> entered = ""
                        else -> if (entered.length < 4) entered += n
                    }
                    refreshDots()
                    if (entered.length == 4) checkPin()
                }
                val lp = LinearLayout.LayoutParams(0, 53, 1f)
                lp.setMargins(5, 4, 5, 4)
                line.addView(b, lp)
            }
            grid.addView(line)
        }
        root.addView(grid, LinearLayout.LayoutParams(-1, 232))
    }

    private fun refreshDots() {
        dots.text = (0..3).joinToString("   ") { i -> if (i < entered.length) "●" else "○" }
    }

    private fun checkPin() {
        if (mode == "new") {
            newPin = entered
            entered = ""
            mode = "confirm"
            message.text = "ULANGI PIN BARU"
            refreshDots()
            return
        }
        if (mode == "confirm") {
            if (entered == newPin) {
                prefs.edit().putString("pin", newPin).apply()
                showLock()
                message.text = "PIN BERHASIL DIPERBARUI"
            } else {
                entered = ""
                newPin = ""
                mode = "new"
                message.text = "TIDAK COCOK. BUAT PIN BARU LAGI"
                refreshDots()
            }
            return
        }
        if (mode == "verify") {
            if (entered == pin()) {
                entered = ""
                mode = "new"
                message.text = "MASUKKAN PIN BARU"
                refreshDots()
            } else {
                entered = ""
                refreshDots()
                message.text = "PIN LAMA SALAH"
            }
            return
        }
        if (entered == pin()) showUnlocked() else {
            entered = ""
            refreshDots()
            message.text = "AKSES DITOLAK • PIN SALAH"
        }
    }

    private fun startChangePin() {
        mode = "verify"
        entered = ""
        setup("VERIFIKASI PEMILIK", "MASUKKAN PIN SAAT INI")
        dots = text("○   ○   ○   ○", 27f, gold, true)
        root.addView(dots, LinearLayout.LayoutParams(-1, 48))
        message = text("PIN LAMA DIPERLUKAN", 12f, 0xFF9CA3AF.toInt())
        root.addView(message, LinearLayout.LayoutParams(-1, 34))
        addKeypad()
        val back = makeButton("KEMBALI", false)
        back.setOnClickListener { showLock() }
        root.addView(back, LinearLayout.LayoutParams(-1, 48))
    }

    private fun makeButton(label: String, keypad: Boolean): Button =
        Button(this).apply {
            text = label
            textSize = if (keypad) 21f else 13f
            setTextColor(if (keypad) gold else dark)
            isAllCaps = false
            typeface = Typeface.DEFAULT_BOLD
            background = background(if (keypad) panel else gold, 18f, if (keypad) 0xFF424957.toInt() else 0)
        }

    private fun showUnlocked() {
        setup("BRANKAS TERBUKA", "IDENTITAS BERHASIL DIVERIFIKASI")
        addVaultIcon()
        root.addView(text("AKSES DIIZINKAN", 20f, gold, true),
            LinearLayout.LayoutParams(-1, 52))
        root.addView(text("Selamat datang di ruang VAULT LOCK.\nArea ini adalah halaman simulasi brankas digital.",
            14f, 0xFFD1D5DB.toInt()), LinearLayout.LayoutParams(-1, 90))
        val lock = makeButton("KUNCI KEMBALI", false)
        lock.setOnClickListener { showLock() }
        root.addView(lock, LinearLayout.LayoutParams(-1, 54))
    }
}
